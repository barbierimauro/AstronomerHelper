
#include "ClockCorrections/readCircularT.h"
#include <cstdio>
#include <cstring>
#include <string>

namespace ClockCorrections
{

  ClockConversion
  readCircularT_UTC(const std::string &fname,
		    const std::string &clockname)
  {
    FILE *f =  std::fopen(fname.c_str(), "r");
    if (!f)
      throw "Unable to open file";

    ClockConversion function("UTC("+clockname+")", "UTC");
    function.add_dated_comment(std::string("Imported from file ")+fname);

    // get MJDs covered by this circular
    char line[1024], label[1024];
    int nread=0;
    double mjd[8];
    while (std::fgets(line, 1024, f))
    {
      sscanf(line, "%s", label);
      if (!std::strcmp(label, "MJD"))
      {
	nread = sscanf(line, "%*s %lf %lf %lf %lf %lf %lf %lf %lf",
		       &mjd[0], &mjd[1], &mjd[2], &mjd[3], 
		       &mjd[4], &mjd[5], &mjd[6], &mjd[7]);
	break;
      }
    }
    if (nread < 1)
      throw "Error parsing circular T file!";

    // get UTC - <clock> for those mjds, and construct function
    double offset[8];
    int i, nread2;
    while (std::fgets(line, 1024, f))
    {
      sscanf(line, "%s", label);
      if (clockname == label)
      {
	nread2 = sscanf(line, "%*s %*s %lf %lf %lf %lf %lf %lf %lf %lf",
		   &offset[0], &offset[1], &offset[2], &offset[3], 
		   &offset[4], &offset[5], &offset[6], &offset[7]);
	for (i=0; i < nread; i++)
	  function.insert_value(std::pair<double,double>
				(mjd[i], offset[i]*1.0e-9));
	break;
      }
    }
    if (nread2 < nread)
    {
      std::fprintf(stderr, 
		   "Error parsing circular T file %s for UTC-UTC(xxx)!",
		   fname.c_str());
      std::exit(1);
    }
    std::fclose(f);
    
    return function;
 }


  ClockConversion
  readCircularT_NIST(const std::string &fname)
  {
    return readCircularT_UTC(fname, "NIST");
  }

  ClockConversion
  readCircularT_AUS(const std::string &fname)
  {
    return readCircularT_UTC(fname, "AUS");
  }


  ClockConversion
  readCircularT_GPS(const std::string &fname)
  {
    FILE *f =  std::fopen(fname.c_str(), "r");
    if (!f)
      throw "Unable to open file";

    ClockConversion function("UTC(GPS)", "UTC");
    function.add_dated_comment(std::string("Imported from file ")+fname);

    // search for the header line, it has MJD and C0 in it
    // (seems to work for all cirts presently in CVS)
    char line[1024];
    std::string s;
    while (std::fgets(line, 1024, f))
    {
      s = line;
      if ( (s.find("MJD")!=std::string::npos)
	   && (s.find("C0")!=std::string::npos))
	break;
    }

    // now get all lines with an MJD in column 3, up til
    // the next section, which might include words like "TAI",
    // "BIPM" etc
    double mjd, offset;
    while (std::fgets(line, 1024, f))
    {
      s = line;
      if (s.find("TAI")!=std::string::npos
	  || s.find("BIPM")!=std::string::npos)
	break;
      if (sscanf(line, "%*s %*s %lf %lf\n", &mjd, &offset)==2
	  && mjd > 40000.0 && mjd < 70000.0)
	  function.insert_value(std::pair<double,double>
				(mjd, offset*1.0e-9));
      // NOTE:
      // Actually there is an integer number of seconds omitted from
      // this offset! However, there is also an equal number of seconds
      // omitted from the pks-gps offset, so they will cancel later
    }

    if (function.getValues().size() < 1)
      throw "Error parsing Circular T!";

    std::fclose(f);
    
    return function;
  }

    
}
