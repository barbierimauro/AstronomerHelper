
#include "ClockCorrections/ClockConversion.h"

#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <cctype>
#include <cstring>

namespace ClockCorrections
{
  //this should go in a library somewhere.
  int cmp_nocase(const std::string& s1, const std::string& s2) 
  {
    //======================================================================
    // compare two strings without caring about case
    // taken from Stroustrup Special Ed, 20.3.8
    //======================================================================
    std::string::const_iterator p1=s1.begin();
    std::string::const_iterator p2=s2.begin();
    while (p1!=s1.end() && p2!=s2.end()) {
      if (std::toupper(*p1) != std::toupper(*p2))
	return (std::toupper(*p1)<std::toupper(*p2)) ? -1 : 1;
      ++p1; ++p2;
    }
    return (s2.size()==s1.size()) ? 0 : (s1.size()<s2.size()) ? -1:1;
  }


  ClockConversion::ClockConversion(const std::string &clockFrom_,
				   const std::string &clockTo_) 
    :  NUSFunction<double,double>(), clockFrom(clockFrom_), clockTo(clockTo_) 
  {}

  
  ClockConversion::ClockConversion(const std::string &fname)
    :  NUSFunction<double,double>()
  {
    load(fname);
  }

  void 
  ClockConversion::load(const std::string &fname)
  {
    FILE *f;
    char line[1024], *c;

    f = std::fopen(fname.c_str(), "r");
    if (f==NULL)
    {
      std::fprintf(stderr, 
		   "Fatal Error: Unable to open file %s for reading\n",
		   fname.c_str());
      std::exit(1);
    }
    
    // parse first line
    std::fgets(line, 1024, f);
    if (line[0]!='#')
    {
      std::fprintf(stderr, 
	      "Error parsing clock file %s: first line must begin with #\n",
	      fname.c_str());
      std::exit(1);
    }
    for (c=line; *c=='#'; c++)
      ;
    char fstr[32], tstr[32], bstr[32];
    bstr[0]='\0';
    if (std::sscanf(c, "%s %s %s", fstr, tstr, bstr)<2)
    {
      fprintf(stderr, 
	      "Error parsing clock file %s: first line must be of form # clock_from clock_to [badness]\n",
	      fname.c_str());
      exit(1);
    }
    clockFrom = fstr;
    clockTo = tstr;
    badness = bstr;

    // parse clock correction lines 
    std::pair<double,double> sample;
    bool in_data_block=false;
    bool warning_displayed=false;
    while (fgets(line, 1024, f)!=NULL)
    {
      line[strlen(line)-1] = '\0'; // zap newline
      if (line[0]=='#')
      {
	comments.push_back(line+1);
	if (in_data_block && !warning_displayed)
	{
	  fprintf(stderr, "Warning: comments interspersed with data in %s.\n",
		  fname.c_str());
	  fprintf(stderr, "These will be moved to before data begins if saved.\n");
	  warning_displayed=true;
	}
      }
      else
      {
	if (sscanf(line, "%lf %lf", &sample.first, &sample.second)==2)
	{
	  insert_value(sample);
	  in_data_block = true;
	}
      }
    }
    
    fclose(f);
  }
  
  void
  ClockConversion::save(const std::string &fname) const
  {
    FILE *f;

    f = std::fopen(fname.c_str(), "w");
    if (f==NULL)
    {
      std::fprintf(stderr, 
		   "Fatal Error: Unable to open file %s for writing\n",
		   fname.c_str());
      std::exit(1);
    }
    
    fprintf(f, "# %s %s %s\n", clockFrom.c_str(), clockTo.c_str(), badness.c_str());
    int ic, nc=comments.size();
    for (ic=0; ic < nc; ic++)
      fprintf(f, "#%s\n", comments[ic].c_str());

      std::vector<std::pair<double, double> >::size_type  
       i, n = values.size();
     for (i=0; i < n; i++)
       std::fprintf(f, "%11.5lf %12.5le\n", values[i].first, values[i].second);
    

    fclose(f);
  }

  void
  ClockConversion::merge(const ClockConversion &in, 
			 double min_distance)
  {
    if (cmp_nocase(clockFrom, in.clockFrom) 
	|| cmp_nocase(clockTo, in.clockTo))
    {
      std::fprintf(stderr, "Error! Tried to merge two different clock conversions:\n");
      std::fprintf(stderr, "%s->%s vs %s->%s\n", 
		   clockFrom.c_str(), clockTo.c_str(),
	      in.clockFrom.c_str(), in.clockTo.c_str());
      std::exit(1);
    }
    
    NUSFunction<double,double>::merge(in, min_distance);
    
    if (in.comments.size()!=0)
    {
      comments.push_back
	("Comments from merged data file:");
      int ic, nc=in.comments.size();
      for (ic=0; ic < nc; ic++)
	comments.push_back(std::string(">") + in.comments[ic]);
    }    
  }

  void
  ClockConversion::add_dated_comment(const std::string &comment)
  {
    std::time_t timer=std::time(NULL);
    char timestr[32];
    std::strcpy(timestr, std::asctime(std::localtime(&timer)));
    timestr[std::strlen(timestr)-1] = '\0'; // chop off \n
    comments.push_back(std::string(timestr) + " " + comment);
  }

  double
  ClockConversion::get_mjd_start() const
  {
    return getValues()[0].first;
  }


  double
  ClockConversion::get_mjd_end() const
  {
    return getValues()[getValues().size()-1].first;
  }
}
