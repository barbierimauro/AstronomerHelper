
#include "ClockCorrections/NUSFunction.h"

#include <cstdio>
#include <cctype>

namespace ClockCorrections
{

  template <>
  void
  NUSFunction<double,double>::write(FILE *f) const
  {
      std::vector<std::pair<double, double> >::size_type  
       i, n = values.size();
     for (i=0; i < n; i++)
       std::fprintf(f, "%.10lg %.10lg\n", values[i].first, values[i].second);
  }
  template <>
  void
  NUSFunction<double,double>::read(FILE *f) 
  {
    char line[1024], *c;
    while (std::fgets(line, 1024, f)==line)
    {
      for (c=line; *c && isspace(*c); c++)
	; // skip whitespace
      if (*c && *c != '#') // ignore blank lines and comments
      {
	double x, y;
	if (sscanf(c, "%lf %lf", &x, &y)!=2)
	  throw "Error parsing NUS data!";
	insert_value(std::make_pair(x,y));
      }
    }
  }
}
