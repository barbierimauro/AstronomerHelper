// redwards program to produce (part of) time.dat as used by
// old tempo.
// Tempo expects UTC(NIST) - UTC(observatory) in the "second" column of
// its fixed format file; we leave the first column empty

#include <cstdio>
#include <unistd.h>
#include <string>
#include <cmath>

#include "ClockCorrections/ClockConversionChain.h"

using namespace ClockCorrections;

void
usage()
{
  std::fprintf(stderr, "Usage:\n");
  std::fprintf(stderr, "make_time_dat [options]\n");
  std::fprintf(stderr, "     -m \"mjd1 [mjd2 [mjd_step]]\"                       Range/spacing of data\n");
  std::fprintf(stderr, "     -c \"clock_from clkfile1 ... clkfileN clock_to\"\n");
  std::fprintf(stderr, "         --- Specify a conversion chain [def: utc(pks) pks2gps gps2utc nist2utc utc]\n");
  std::fprintf(stderr, "     -s site code [7]\n");
  std::fprintf(stderr, "Example (silly but illustrative):\n");
  std::fprintf(stderr, "make_time_dat -m \"51000 51100\" -c \"UtC(PKs) pks2gps gps2utc nist2utc nist\"\n");
  std::exit(1);
}


void
print_time_dat(const ClockConversionChain &chain, char site,
		  double mjd1, double mjd2, double mjd_step)
{
  double mjd;

  for (mjd=std::ceil(mjd1); mjd<=mjd2; mjd+=mjd_step)
    std::printf(" %8.2lf %23.3lf %c\n", mjd, 
		chain.get_correction(mjd)*1.0e6, site);
}

int
main(int argc, char *argv[])
{
  double mjd1=-1.0, mjd2=-1.0, mjd_step=1.0;
  int c;
  char site='7';
  std::string chain_str = "utc(pks) pks2gps gps2utc nist2utc utc(nist)";
  ClockConversionChain chain;

  while ((c=getopt(argc, argv, "m:c:s:"))!=-1)
  {
    switch (c)
    {
      case 's':
      {
	site = optarg[0];
	break;
      }
      case 'm':
      {
	int narg = sscanf(optarg, "%lf %lf %lf", &mjd1, &mjd2, &mjd_step);
	if (narg < 1)
	  usage();
	if (narg == 1)
	  mjd2 = -1.0;
	if (narg == 2)
	  mjd_step = 1.0;
	break;
      }
      case 'c':
      {
         chain_str = optarg;
         break;
      }
    default:
      usage();
      break;
     }

  }


  	// break arg up into strings
	std::vector<std::string> strings;
	std::string arg(chain_str);
	std::string::size_type p1, p2;
	std::string white(" \n\r\t");
	for (p1=arg.find_first_not_of(white);
	     p1!=std::string::npos;
	     p1=arg.find_first_not_of(white, p2))
	{
	  p2 =  arg.find_first_of(white,p1);
	  if (p2 == std::string::npos)
	  {
	    strings.push_back(arg.substr(p1, arg.length()-p1));
	    break;
	  }
	  else
	    strings.push_back(arg.substr(p1, p2-p1));
	}
	// save it
	chain = ClockConversionChain
			 (strings[0], strings[strings.size()-1],
			  std::vector<std::string>(strings.begin()+1,
						    strings.end()-1));
  if (mjd1 < 0.0)
    mjd1 = chain.get_mjd_start();
  if (mjd2 < 0.0)
    mjd2 = chain.get_mjd_end();



  
  print_time_dat(chain, site, mjd1, mjd2, mjd_step);

  return 0;
}
