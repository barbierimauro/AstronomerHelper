
#include "ClockCorrections/readParkesGPS.h"
#include <cstdio>
#include <cmath>

namespace ClockCorrections
{

ClockConversion
readParkesGPS4(const std::string &fname, double clipval)
{
  // happily, the data we want from this file is in the same
  // columns as it is in the mk6 monitoring!
  return readParkesGPS6(fname, clipval);
}


ClockConversion
readParkesGPS6(const std::string &fname, double clipval)
{
  FILE *f = std::fopen(fname.c_str(), "r");
  if (!f)
    throw "Unable to open file";

  int date_day, date_seconds;
  double offset;
  char line[1024], *c;
  int iline=0;
  ClockConversion function("UTC(PKS)", "UTC(GPS)");
  function.add_dated_comment(std::string("Imported from file ")+fname);

  while (std::fgets(line, 1024, f))
  { 
    iline++;
    // check for comments
    for (c=line; *c && *c!='#'; c++)
      ;
    if (*c=='\0') // not a comment
    {
      if (!sscanf(line, "%*s %*s %*s %*s %d %d %lf", 
		  &date_day, &date_seconds, &offset))
      {
	std::fprintf(stderr, "Error parsing file %s, line %d\n",
		     fname.c_str(), iline);
	std::exit(1);
      }

      offset = -offset; // file has PKS-GPS, we want GPS-PKS
      double mjd = date_day + date_seconds/86400.0;

      // Apply corrections for re-configurations of the monitoring system.
      // see readParkesGPS.h
      if (mjd < 51835.0)
	offset -= 92.0e-9;
      if (mjd < 52241.0)
	offset += 40.0e-9;

      // clip if neccesary and store
      if (std::fabs(offset) < clipval)
	function.insert_value(std::pair<double,double>(mjd, offset)); 
            
      // NOTE:
      // Actually there is an integer number of seconds omitted from
      // this offset! However, there is also an equal number of seconds
      // omitted from the utc-gps offset, so they will cancel later
    }
  }
  
  std::fclose(f);

  return function;
}

}
