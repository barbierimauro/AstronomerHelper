
#include <cstdio>
#include <cmath>

#include "ClockCorrections/NUSAlgorithm.h"


using namespace std;
using namespace ClockCorrections;



template <typename XT, typename YT>
void
do_it(FILE *fin, FILE *fout)
{ 
  NUSFunction<XT,YT> input(fin), spec;

  LombScargle(input, spec, 10.0, 1.0);

  //   spec.write(fout);
  //   return;
   NUSFunction<XT,YT> output;
  const std::vector<std::pair<XT,YT> > vals = spec.getValues();
  int i, n=spec.getValues().size();
  for (i=0; i < n; i++)
  {
    if (vals[i].first > 0.0)
      output.insert_value(std::make_pair(std::log10(vals[i].first), 
					 vals[i].second));
  }
  output.scrunch(1.0/50);
  output.write(fout);
}
 
int
main(int argc, char *argv[])
{
  FILE *fin = fopen(argv[1], "r");
  FILE *fout = fopen(argv[2], "w");

  do_it<double, double>(fin, fout);
}
